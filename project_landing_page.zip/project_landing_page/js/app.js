/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/

const itemsDomFragment = document.createDocumentFragment();
const sections = document.querySelectorAll('section');
const navbarMenu = document.querySelector('.navbar__menu')
const listItem = document.getElementById('navbar__list');
const activeNav = document.querySelector('.isActive');
const buttonBackToTop = document.querySelector('.button_top');
const navItems = [];
let timeOutScroll;

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



// remove navbar
function removeNavbar() {
    navbarMenu.style.display = 'none';
}

// show the navbar using setTimeout
function showNavbar() {
    navbarMenu.style.display = 'block';
    clearTimeout(timeOutScroll);
    timeOutScroll = setTimeout(removeNavbar, 3000);
}

// change the style for navbar when scroll
function flipNavbarStyle() {
    const items = document.querySelectorAll('li');
    const scrollPosition = window.scrollY;
    if (scrollPosition > 380) {
        navbarMenu.style.background = '#03123F';
        for (let i = 0; i < items.length; i++) {
            items[i].classList.add('scroll_menu_link');
        }
    }
    else {
        navbarMenu.style.background = '#fff';
        for (let i = 0; i < items.length; i++) {
            items[i].classList.remove('scroll_menu_link');
        }
    }
}

// back to the top
function backToTop(event) {
    event.preventDefault();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav 
function genarationNavbar() {
    for (let i = 0; i < sections.length; i++) {
        const liElement = document.createElement('li');
        liElement.innerHTML = sections[i].getAttribute('data-Nav');
        liElement.classList.add('menu__link');
        itemsDomFragment.appendChild(liElement);
        navItems.push(liElement);
    }

    listItem.appendChild(itemsDomFragment);
}
genarationNavbar()

// Add class 'active' to section when near top of viewport 
function setActive() {
    sections.forEach((section, index) => {
        const box = section.getBoundingClientRect();
        if (box.top <= 60 && box.bottom >= 60) {
            section.classList.add('isActive');
            navItems[index].classList.add('active');
        }
        else {
            section.classList.remove('isActive');
            navItems[index].classList.remove('active');
        }
    })
}

// Scroll to anchor ID using scrollIntoView event
function checkIsActiveState(event) {
    event.preventDefault();
    const { target } = event;
    for (let i = 0; i < sections.length; i++) {
        if (target.textContent === sections[i].getAttribute('data-Nav')) {
            sections[i].classList.add('isActive');
            sections[i].scrollIntoView({ behavior: 'smooth' });
        }
        else {
            sections[i].classList.remove('isActive');
        }
    }
}

/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 
listItem.addEventListener('click', checkIsActiveState);

// Scroll to section on link click
document.addEventListener('scroll', () => {
    setActive();
    flipNavbarStyle();
    showNavbar();
});

// Scroll to top on click on back button
buttonBackToTop.addEventListener('click', backToTop);

